CreateObject("Wscript.Shell").Run "py main.py", 0, False
